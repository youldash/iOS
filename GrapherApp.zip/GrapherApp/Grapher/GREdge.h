//
//  GREdge.h
//  Grapher
//
//  Created by Mustafa Youldash on 19/02/2016.
//  Copyright © 2016 Umm Al-Qura University. All rights reserved.
//
//  Except where otherwise noted, this work is vested in Umm Al-Qura University <http://www.uqu.edu.sa/> and is licensed under the
//  Creative Commons Attribution-NonCommercial 4.0 International License <http://creativecommons.org/licenses/by-nc/4.0/>.
//
//  Unless otherwise stated, no part of this work may be reproduced and redistributed by any process,
//  nor used for commercial purposes without the written permission of Umm Al-Qura University and the author.
//
//  If you modify or build upon the work, you may only distribute the resulting work under the same license conditions as this one.
//

@import Foundation;
@import UIKit;
@import SpriteKit;

#import "GRAbstractGraph.h"

@class GRNode;
@class GRScene;

/**
 *  Protocol implemented by a graph edge.
 */
@protocol GREdgeDelegate <NSObject>

#pragma mark -
#pragma mark Accessing

/**
 *  An identifier.
 */
@property (copy, nonatomic) NSString *identifier;

/**
 *  A weight on this graphic.
 */
@property (strong, nonatomic) NSNumber *weight;

/**
 *  The head node of this edge.
 */
@property (readonly, nonatomic) GRNode *head;

/**
 *  The tail node of this edge.
 */
@property (readonly, nonatomic) GRNode *tail;

/**
 *  Circular reference to an undirected graph that contains this edge (not retained).
 */
@property (weak, nonatomic) id<GRGraphDelegate> graph;

/**
 *  Circular reference to a Grapher scene (not retained).
 */
@property (weak, nonatomic) GRScene *scene;

/**
 *  The color to draw the edge with.
 */
@property (copy, nonatomic) SKColor *color;

/**
 *  Edge color.
 *
 *  @return The color.
 */
+ (SKColor *)edgeColor;

#pragma mark -
#pragma mark Querying

/**
 *  The mate node for the given node.
 *
 *  @param  node  A node of this edge.
 *
 *  @return  The mate of the given node.
 */
- (GRNode *)mateOfNode:(GRNode *)node;

@end

#pragma mark -

/**
 *  Represents an edge in a graph.
 */
@interface GREdge : SKShapeNode <GREdgeDelegate>

#pragma mark -
#pragma mark Accessing

/**
 *  The index of the head node.
 */
@property (assign, nonatomic) NSUInteger headIdx;

/**
 *  The index of the tail node.
 */
@property (assign, nonatomic) NSUInteger tailIdx;

#pragma mark -
#pragma mark Initializing

/**
 *  Designated initializer.
 *  Initializes a newly allocated edge with the given graph, head and tail node indices, weight, color, line width, and scene reference.
 *
 *  @param  identifier  An identifier.
 *  @param  graph    An undirected graph.
 *  @param  weight    A weight.
 *  @param  headIdx    The index of the head node.
 *  @param  tailIdx    The index of the tail node.
 *  @param  color    A color vector.
 *  @param  scene    A Grapher scene associated with this edge.
 *
 *  @return  The new edge.
 */
- (instancetype)initWithIdentifier:(id<NSObject>)identifier
                             graph:(id<GRGraphDelegate>)graph
                            weight:(NSNumber *)weight
                emanatingFromIndex:(NSUInteger)headIdx
                   insidentOnIndex:(NSUInteger)tailIdx
                             color:(UIColor *)color
                             scene:(GRScene *)scene;

@end
