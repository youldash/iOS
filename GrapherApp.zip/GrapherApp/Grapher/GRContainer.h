//
//  GRContainer.h
//  Grapher
//
//  Created by Mustafa Youldash on 20/02/2016.
//  Copyright © 2016 Umm Al-Qura University. All rights reserved.
//
//  Except where otherwise noted, this work is vested in Umm Al-Qura University <http://www.uqu.edu.sa/> and is licensed under the
//  Creative Commons Attribution-NonCommercial 4.0 International License <http://creativecommons.org/licenses/by-nc/4.0/>.
//
//  Unless otherwise stated, no part of this work may be reproduced and redistributed by any process,
//  nor used for commercial purposes without the written permission of Umm Al-Qura University and the author.
//
//  If you modify or build upon the work, you may only distribute the resulting work under the same license conditions as this one.
//

#import "GRAbstractEnumerable.h"
#import "GREnumerable.h"

/**
 *  Protocol implemented by all containers.
 */
@protocol GRContainerDelegate <GREnumerableDelegate>

#pragma mark -
#pragma mark Accessing

/**
 *  The number of objects in this container.
 */
@property (readonly, nonatomic) NSUInteger count;

/**
 *  Indicates whether this container is empty.
 */
@property (readonly, nonatomic) BOOL isEmpty;

/**
 *  Indicates whether this container is full.
 */
@property (readonly, nonatomic) BOOL isFull;

/**
 *  Purges the objects from this container.
 */
- (void)purge;

@end

#pragma mark -

/**
 *  Base class from which all containers are derived.
 */
@interface GRContainer : GRAbstractEnumerable <GRContainerDelegate> {
    
    /**
     *  The number of objects in this container.
     */
    NSUInteger _count;
}

#pragma mark -
#pragma mark Testing

/**
 *  GRContainer test program.
 *
 *  @param  container  The container to test.
 *
 *  @return  A boolean value that indicates whether all the tests were successful.
 */
+ (BOOL)testContainer:(id<GRContainerDelegate>)container;

@end
