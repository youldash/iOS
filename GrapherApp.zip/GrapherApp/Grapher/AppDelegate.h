//
//  AppDelegate.h
//  Grapher
//
//  Created by Mustafa Youldash on 16/02/2016.
//  Copyright © 2016 Umm Al-Qura University. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

