//
//  GRContainer.m
//  Grapher
//
//  Created by Mustafa Youldash on 20/02/2016.
//  Copyright © 2016 Umm Al-Qura University. All rights reserved.
//
//  Except where otherwise noted, this work is vested in Umm Al-Qura University <http://www.uqu.edu.sa/> and is licensed under the
//  Creative Commons Attribution-NonCommercial 4.0 International License <http://creativecommons.org/licenses/by-nc/4.0/>.
//
//  Unless otherwise stated, no part of this work may be reproduced and redistributed by any process,
//  nor used for commercial purposes without the written permission of Umm Al-Qura University and the author.
//
//  If you modify or build upon the work, you may only distribute the resulting work under the same license conditions as this one.
//

#import "GRContainer.h"

@implementation GRContainer

#pragma mark -
#pragma mark Initializing

/**
 *  Designated initializer.
 *  Initializes a newly allocated container.
 *
 *  @return  The new container.
 */
- (instancetype)init
{
    NSAssert(![self isMemberOfClass:[GRContainer class]], @"GRContainer class instantiated.");
    
    // Immutable container, just return a new reference to itself (retained automatically by ARC).
    self = [super init];
    
    if (self) {
        
        // Initialize all parameters.
        _count = 0;
    }
    
    // Return this container along with its children.
    return self;
}

#pragma mark -
#pragma mark Accessing

/**
 *  The number of objects in this container.
 */
@synthesize count = _count;

#pragma mark -
#pragma mark Querying

/**
 *  Returns a string that describes this container.
 *
 *  @return  The string.
 */
- (NSString *)description
{
    NSMutableString *string = [NSMutableString string];
    
    for (id object in self) {
        
        if (string.length > 0)
            [string appendFormat:@", "];
        
        [string appendFormat:@"%@", object];
    }
    
    return [NSString stringWithFormat:@"<%@: %@>", [self class], string];
}

#pragma mark -
#pragma mark OCContainerDelegate

/**
 *  Indicates whether this container is empty.
 *
 *  @return The boolean result.
 */
- (BOOL)isEmpty
{
    return _count == 0;
}

/**
 *  Indicates whether this container is full.
 *
 *  @return The boolean result.
 */
- (BOOL)isFull
{
    return NO;
}

/**
 *  Removes all the objects from this container.
 */
- (void)purge
{
    [self doesNotRecognizeSelector:_cmd];
}

#pragma mark -
#pragma mark Testing

/**
 *  GRContainer unit test program.
 *
 *  @param  container  The container to test.
 *
 *  @return  A boolean value that indicates whether all the tests were successful.
 */
+ (BOOL)testContainer:(id<GRContainerDelegate>)container
{
    [GRAbstractEnumerable testEnumerable:container];
    
    NSLog(@"GRContainer test program.\n\
          --------------------------------------------");
    
    NSLog(@"container = %@", container);
    NSLog(@"count = %lu", container.count);
    NSLog(@"isEmpty = %@", container.isEmpty ? @"YES" : @"NO");
    NSLog(@"isFull = %@", container.isFull ? @"YES" : @"NO");
    
    NSLog(@"Purging...");
    [container purge];
    NSLog(@"container = %@", container);
    NSLog(@"count = %lu", container.count);
    NSLog(@"isEmpty = %@", container.isEmpty ? @"YES" : @"NO");
    NSLog(@"isFull = %@", container.isFull ? @"YES" : @"NO");
    
    return YES;
}

@end
