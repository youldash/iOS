//
//  GRIntegerArray.h
//  Grapher
//
//  Created by Mustafa Youldash on 20/02/2016.
//  Copyright © 2016 Umm Al-Qura University. All rights reserved.
//
//  Except where otherwise noted, this work is vested in Umm Al-Qura University <http://www.uqu.edu.sa/> and is licensed under the
//  Creative Commons Attribution-NonCommercial 4.0 International License <http://creativecommons.org/licenses/by-nc/4.0/>.
//
//  Unless otherwise stated, no part of this work may be reproduced and redistributed by any process,
//  nor used for commercial purposes without the written permission of Umm Al-Qura University and the author.
//
//  If you modify or build upon the work, you may only distribute the resulting work under the same license conditions as this one.
//

@import Foundation;

/**
 *  A tuple.
 *	Tuples are a grouping of multiple values into a single type
 *
 *  @param i The first integer.
 *  @param j The second integer.
 *
 *  @return The new integer array.
 */
#define GRTuple(i, j) [GRIntegerArray arrayWithIntegers:i :j]

/**
 *  Represents an array of integers.
 */
@interface GRIntegerArray : NSObject <NSCopying, NSFastEnumeration>

#pragma mark -
#pragma mark Accessing

/**
 *  A C array of integers.
 */
@property (readonly, nonatomic) NSInteger *data;

/**
 *	The length of this array.
 */
@property (assign, nonatomic) NSUInteger length;

/**
 *	The base index of this array.
 */
@property (assign, nonatomic) NSUInteger baseIndex;

#pragma mark -
#pragma mark Creating

/**
 *	Returns a new array with the default length and base index.
 *
 *	@return	The new array.
 */
+ (instancetype)array;

/**
 *	Returns a new array with the given length.
 *
 *	@param	length	The length of the array.
 *
 *	@return	The new array.
 */
+ (instancetype)arrayWithLength:(NSUInteger)length;

/**
 *	Returns a new array with the given length and base index.
 *
 *	@param	length		The length of the array.
 *	@param	baseIndex	The base index of the array.
 *
 *	@return	The new array.
 */
+ (instancetype)arrayWithLength:(NSUInteger)length baseIndex:(NSUInteger)baseIndex;

/**
 *	Returns a new array with the given length, base index, and initial value.
 *
 *	@param	length		The length of the array.
 *	@param	baseIndex	The base index of the array.
 *	@param	value		The initial value.
 *
 *	@return	The new array.
 */
+ (instancetype)arrayWithLength:(NSUInteger)length baseIndex:(NSUInteger)baseIndex initialValue:(NSInteger)value;

/**
 *  Returns a new array with the given length and values.
 *
 *	@param	length	The length of the array.
 *	@param	integer	The first integer.
 *	@param ...		The rest of the integers.
 *
 *  @return The new array.
 */
+ (instancetype)arrayWithLength:(NSUInteger)length integers:(NSInteger)integer, ...;

/**
 *  Returns an array of length 2 that contains the given integers.
 *
 *	@param	firstInteger	The first integer.
 *	@param	secondInteger	The second integer.
 *
 *  @return The new array.
 */
+ (instancetype)arrayWithIntegers:(NSUInteger)firstInteger :(NSInteger)secondInteger;

/**
 *  Returns an array of length 3 that contains the given integers.
 *
 *	@param	firstInteger	The first integer.
 *	@param	secondInteger	The second integer.
 *	@param	thirdInteger	The third integer.
 *
 *  @return The new array.
 */
+ (instancetype)arrayWithIntegers:(NSUInteger)firstInteger :(NSInteger)secondInteger :(NSInteger)thirdInteger;

#pragma mark -
#pragma mark Initializing

/**
 *	Initializes a newly allocated array with the given length.
 *
 *	@param	length	The length of the array.
 *
 *	@return	The new array.
 */
- (instancetype)initWithLength:(NSUInteger)length;

/**
 *	Initializes a newly allocated array with the given length and base index..
 *
 *	@param	length		The length of the array.
 *	@param	baseIndex	The base index of the array.
 *
 *	@return	The new array.
 */
- (instancetype)initWithLength:(NSUInteger)length baseIndex:(NSUInteger)baseIndex;

/**
 *	Initializes a newly allocated array with the given length, base index and initial value.
 *
 *	@param	length		The length of the array.
 *	@param	baseIndex	The base index of the array.
 *	@param	value		The initial value.
 *
 *	@return	The new array.
 */
- (instancetype)initWithLength:(NSUInteger)length baseIndex:(NSUInteger)baseIndex initialValue:(NSInteger)value;

#pragma mark -
#pragma mark Querying

/**
 *	Returns the int value at the given index in this array.
 *
 *	@param	index	An array index.
 *
 *	@return	The integer value.
 */
- (NSInteger)integerAtIndex:(NSUInteger)index;

#pragma mark -
#pragma mark Modifying

/**
 *	Replaces the integer at the given index in this array with the given integer.
 *
 *	@param	index	An array index.
 *	@param	integer	An integer.
 *
 *	@return	The object originally at the given index in this array.
 */
- (NSInteger)replaceIntegerAtIndex:(NSUInteger)index withInteger:(NSInteger)integer;

/**
 *	Exchanges the integers at the given indices in this array.
 *
 *	@param	index1	An array index.
 *	@param	index2	An array index.
 */
- (void)exchangeIntegerAtIndex:(NSUInteger)index1 withIntegerAtIndex:(NSUInteger)index2;

/**
 *	Removes all the objects from this array.
 */
- (void)purge;

/**
 *  Executes the Fisher Yates shuffling algorithm.
 *  Shuffles the contents of this array for random pick of the points.
 *
 *  @discussion This method enhances the OCArray class by providing methods to randomly shuffle the elements.
 */
- (void)shuffle;

#pragma mark -
#pragma mark Testing

/**
 *	GRIntegerArray unit test program.
 *
 *	@return	A boolean value that indicates whether all the tests were successful.
 */
+ (BOOL)unitTest;

@end
