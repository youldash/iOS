//
//  GRSceneGraph.m
//  Grapher
//
//  Created by Mustafa Youldash on 21/02/2016.
//  Copyright © 2016 Umm Al-Qura University. All rights reserved.
//
//  Except where otherwise noted, this work is vested in Umm Al-Qura University <http://www.uqu.edu.sa/> and is licensed under the
//  Creative Commons Attribution-NonCommercial 4.0 International License <http://creativecommons.org/licenses/by-nc/4.0/>.
//
//  Unless otherwise stated, no part of this work may be reproduced and redistributed by any process,
//  nor used for commercial purposes without the written permission of Umm Al-Qura University and the author.
//
//  If you modify or build upon the work, you may only distribute the resulting work under the same license conditions as this one.
//

#import "GRSceneGraph.h"
#import "GRMultidimensionalArray.h"
#import "GRIntegerArray.h"
#import "GREdge.h"
#import "GRNode.h"
#import "GRArray.h"

@implementation GRSceneGraph

#pragma mark -
#pragma mark Initializing

/**
 *  Designated initializer.
 *  Initializes a newly allocated graph as matrix with the given length (maximum number of nodes).
 *
 *  @param  identifier  An identifier.
 *  @param  length    The maximum number of nodes.
 *
 *  @return  The new graph as matrix.
 */
- (instancetype)initWithIdentifier:(id<NSObject>)identifier length:(NSUInteger)length
{
    // Immutable graph as matrix, just return a new reference to itself (retained automatically by ARC).
    self = [super initWithIdentifier:identifier length:length];
    
    if (self) {
        
        // Initialize all parameters.
        _matrix = [[GRMultidimensionalArray alloc] initWithDimensions:GRTuple(length, length)];
    }
    
    // Return this graph as matrix along with its children.
    return self;
}

#pragma mark -
#pragma mark GRGraphDelegate

/**
 *  Removes the nodes and edges from this graph as matrix.
 */
- (void)purge
{
    // Purge the matrix.
    [_matrix purge];
    
    // Reset the number of edges to 0.
    _numberOfEdges = 0;
    
    // Purge the node array.
    [super purge];
}

/**
 *  Inserts the given edge into this graph.
 *
 *  @param  edge  The edge to insert.
 */
- (void)insertEdge:(GREdge *)edge
{
    NSUInteger headIdx = edge.head.number;
    NSUInteger tailIdx = edge.tail.number;
    
    NSAssert(headIdx != tailIdx, @"Illegal argument.");
    NSAssert(![self isEdgeFromIndex:headIdx toIndex:tailIdx], @"Illegal argument.");
    
    [_matrix replaceObjectAtIndices:GRTuple(headIdx, tailIdx) withObject:edge];
    [_matrix replaceObjectAtIndices:GRTuple(tailIdx, headIdx) withObject:edge];
    
    // Increment the number of edges by 1.
    _numberOfEdges += 1;
}

/**
 *  Returns the edge in this graph for the given node indices.
 *
 *  @param  index1  The from index.
 *  @param  index2  The to index.
 *
 *  @return  The edge joining the given nodes.
 */
- (GREdge *)edgeFromIndex:(NSUInteger)index1 toIndex:(NSUInteger)index2
{
    return [_matrix objectAtIndices:GRTuple(index1, index2)];
}

#pragma mark -
#pragma mark Testing

/**
 *  GRSceneGraph unit test program.
 *
 *  @return  A boolean value that indicates whether all the tests were successful.
 */
+ (BOOL)unitTest
{
    NSLog(@"GRSceneGraph unit test program.\n\
          --------------------------------------------");
    
    GRSceneGraph *graph = [[GRSceneGraph alloc] initWithIdentifier:@"Scene Graph" length:5];
    [GRAbstractGraph testGraph:graph];
    
    return YES;
}

@end
