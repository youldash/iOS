//
//  GRContainerAsArrayEnumerator.h
//  Grapher
//
//  Created by Mustafa Youldash on 20/02/2016.
//  Copyright © 2016 Umm Al-Qura University. All rights reserved.
//
//  Except where otherwise noted, this work is vested in Umm Al-Qura University <http://www.uqu.edu.sa/> and is licensed under the
//  Creative Commons Attribution-NonCommercial 4.0 International License <http://creativecommons.org/licenses/by-nc/4.0/>.
//
//  Unless otherwise stated, no part of this work may be reproduced and redistributed by any process,
//  nor used for commercial purposes without the written permission of Umm Al-Qura University and the author.
//
//  If you modify or build upon the work, you may only distribute the resulting work under the same license conditions as this one.
//

#import "GREnumerator.h"
#import "GRContainer.h"

@class GRArray;

/**
 *  Represents an enumerator for a container implemented as an array.
 */

@interface GRContainerAsArrayEnumerator : GREnumerator {
    
    /**
     *  The container.
     */
    id<GRContainerDelegate> _container;
    
    /**
     *  The array.
     */
    GRArray *_array;
    
    /**
     *  The number of objects in the container.
     */
    NSUInteger _count;
    
    /**
     *  The array index from which to start the enumeration.
     */
    NSUInteger _fromIndex;
    
    /**
     *  The current position pointer.
     */
    NSUInteger _pointer;
}

#pragma mark -
#pragma mark Initializing

/**
 *  Designed initializer.
 *  Initializes a newly allocated container as array enumerator for the given container, array, count and start index.
 *
 *  @param  container  The container.
 *  @param  array    The underlying array.
 *  @param  count    The number of objects in the array.
 *  @param  index    The start index.
 *
 *  @return  The new container as array enumerator.
 */
- (instancetype)initWithContainer:(id<GRContainerDelegate>)container
                            array:(GRArray *)array
                            count:(NSUInteger)count
                        fromIndex:(NSUInteger)index;

@end
