//
//  GRScene.m
//  Grapher
//
//  Created by Mustafa Youldash on 16/02/2016.
//  Copyright © 2016 Umm Al-Qura University. All rights reserved.
//
//  Except where otherwise noted, this work is vested in Umm Al-Qura University <http://www.uqu.edu.sa/> and is licensed under the
//  Creative Commons Attribution-NonCommercial 4.0 International License <http://creativecommons.org/licenses/by-nc/4.0/>.
//
//  Unless otherwise stated, no part of this work may be reproduced and redistributed by any process,
//  nor used for commercial purposes without the written permission of Umm Al-Qura University and the author.
//
//  If you modify or build upon the work, you may only distribute the resulting work under the same license conditions as this one.
//

#import "GRScene.h"
#import "GRSceneGraph.h"
#import "GRNode.h"
#import "GREdge.h"

/**
 *  Default scene graph length.
 */
#define kGRLengtDefault 10

@implementation GRScene

#pragma mark -
#pragma mark Accessing

/**
 *  Sets the maximum number of nodes.
 */
- (void)setLength:(NSUInteger)length
{
    _length = length;
    
    // If our scene graph is not empty, reset it.
    if ([_graph isValid]) {
        
        [_graph purge];
        _graph = nil;
    }
    
    // Initialize graph data and initial settings.
    _graph = [[GRSceneGraph alloc] initWithIdentifier:@"Scene Graph" length:_length];
}

#pragma mark -
#pragma mark Scene lifecycle

/**
 *  Any values set on nodes here will be used when the scene is rendered for the current frame.
 *
 *  @param view The view.
 */
- (void)didMoveToView:(SKView *)view
{
    /* Setup your scene here. */
    
    // Seed the random number generator.
    srandomdev();
    
    // Initialize graph data and initial settings.
    _graph = [[GRSceneGraph alloc] initWithIdentifier:@"Scene Graph" length:kGRLengtDefault];
    
    // Initialize the log.
    _log = [NSMutableString string];
    
    // Initialize the node number index.
    _idx = 0;
}

/**
 *  Called when a touch begins.
 *
 *  @discussion Generally, all responders which do custom touch handling should override a number of methods.
 *  UIResponder will receive either -touchesEnded:withEvent: or -touchesCancelled:withEvent:
 *  for each touch it is handling (those touches it received in -touchesBegan:withEvent:).
 *
 *  @param touches A set of touches.
 *  @param event   An event.
 */
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    for (UITouch *touch in touches) {
        
        // Attempt to add a new node if, and only if, the graph isn't full. Otherwise, start allover.
        if ([_graph isFull] == NO) {
            
            // Allow conversion of UITouch coordinates to scene-space.
            CGPoint location = [touch locationInNode:self];
            
            // Add a new node to the graph and get its number (index).
            _idx = [_graph addNodeWithIdentifier:NSLocalizedString(@"Node", @"Node Identifier")
                                          weight:@(arc4random_uniform(100)) /* Random weight. */
                                        position:location
                                           color:nil
                                           scene:self];
            
            // Get a reference to the new node.
            GRNode *head = [_graph nodeAtIndex:_idx];
            
            // Add it as a child node of the scene (it must not have a parent).
            [self addChild:head];
            
            // Append log updates.
            [_log appendFormat:@"\n%@", [head description]];
            
            // New node is successfully added. Alert the view controller to play a sound file.
            if ([_sceneDelegate respondsToSelector:@selector(scene:addedNodeWithLog:)])
                [_sceneDelegate scene:self addedNodeWithLog:_log];
            
            // Edges require at least two nodes.
            if (_idx >= 1) {
                
                // Get a reference to the new node.
                GRNode *tail = [_graph nodeAtIndex:_idx - 1];
                
                // Calculate the Euclidean distance from the head to tail nodes.
                double euclideanDistance = [head calculateEuclideanDistanceFromNode:tail];
                
                [_graph addEdgeFromIndex:head.number
                                 toIndex:tail.number
                                  weight:@(euclideanDistance)
                                   scene:self];
                
                // Get a reference to the new node.
                GREdge *edge = [_graph edgeFromIndex:head.number toIndex:tail.number];
                
                // Add it as a child node of the scene (it must not have a parent).
                [self addChild:edge];
            }
            
        } else { // start allover.
            
            // Remove all the nodes and edges from this graph.
            [_graph purge];
            
            // Removes all the nodes and edges from the Grapher scene.
            [self removeAllChildren];
            
            // Re-initialize the node number index.
            _idx = 0;
            
            // Scene graph is purged successfully. Alert the view controller to play a sound file.
            if ([_sceneDelegate respondsToSelector:@selector(scene:purgedGraphWithLog:)])
                [_sceneDelegate scene:self purgedGraphWithLog:_log];
        }
    }
}

/**
 *  Called before each frame is rendered.
 *
 *  @param currentTime The current time interval.
 */
- (void)update:(CFTimeInterval)currentTime
{
    // NSLog(@"%s", __FUNCTION__);
}

@end
