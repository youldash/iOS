//
//  GREnumerator.m
//  Grapher
//
//  Created by Mustafa Youldash on 18/02/2016.
//  Copyright © 2016 Umm Al-Qura University. All rights reserved.
//
//  Except where otherwise noted, this work is vested in Umm Al-Qura University <http://www.uqu.edu.sa/> and is licensed under the
//  Creative Commons Attribution-NonCommercial 4.0 International License <http://creativecommons.org/licenses/by-nc/4.0/>.
//
//  Unless otherwise stated, no part of this work may be reproduced and redistributed by any process,
//  nor used for commercial purposes without the written permission of Umm Al-Qura University and the author.
//
//  If you modify or build upon the work, you may only distribute the resulting work under the same license conditions as this one.
//

#import "GREnumerator.h"

@implementation GREnumerator

#pragma mark -
#pragma mark Initializing

/**
 *  Designated initializer.
 *  Initializes a newly allocated enumerator.
 *
 *  @return The new enumerator.
 */
- (instancetype)init
{
    NSAssert(![self isMemberOfClass:[GREnumerator class]], @"GREnumerator class instantiated.");
    
    // Immutable enumerator, just return a new reference to itself (retained automatically by ARC).
    self = [super init];
    
    // Return this enumerator along with its children.
    return self;
}

#pragma mark -
#pragma mark GREnumeratorDelegate

/**
 *  Indicates whether there are more objects to be enumerated.
 *
 *  @return  The boolean result.
 */
- (BOOL)hasMoreObjects
{
    [self doesNotRecognizeSelector:_cmd];
    return NO;
}

/**
 *  The next object to be enumerated.
 *
 *  @return  The next object.
 */
- (id)nextObject
{
    [self doesNotRecognizeSelector:_cmd];
    return nil;
}

@end
