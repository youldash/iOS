//
//  GRViewController.m
//  Grapher
//
//  Created by Mustafa Youldash on 16/02/2016.
//  Copyright © 2016 Umm Al-Qura University. All rights reserved.
//
//  Except where otherwise noted, this work is vested in Umm Al-Qura University <http://www.uqu.edu.sa/> and is licensed under the
//  Creative Commons Attribution-NonCommercial 4.0 International License <http://creativecommons.org/licenses/by-nc/4.0/>.
//
//  Unless otherwise stated, no part of this work may be reproduced and redistributed by any process,
//  nor used for commercial purposes without the written permission of Umm Al-Qura University and the author.
//
//  If you modify or build upon the work, you may only distribute the resulting work under the same license conditions as this one.
//

#import "GRViewController.h"
#import "GRSceneGraph.h"
#import "GRAbstractGraph.h"

/**
 *  Error code.
 */
#define kGRErrorCode 0

@implementation GRViewController

#pragma mark -
#pragma mark AVAudioPlayerDelegate

/**
 *  For some reason, the audio player fails to load the associated audio file.
 *
 *  @param player An audio player.
 *  @param error  An error.
 */
- (void)audioPlayerDecodeErrorDidOccur:(AVAudioPlayer *)player error:(NSError *)error
{
    // Pass the error to the handler.
    [self handleError:error];
}

/**
 *  Called when a sound has finished playing.
 *  This method is NOT called if the player is stopped due to an interruption.
 *
 *  @param player An audio player.
 *  @param flag   A flag.
 */
- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag
{
    _audioPlayer = nil;
}

#pragma mark -
#pragma mark Audio Playback

/**
 *  Setup audio playback, and play.
 *
 *  @param name      A filename.
 *  @param extension A file extension.
 *  @param sender    A sender.
 */
- (void)setupAudioPlaybackAndPlayResource:(nullable NSString *)name
                            withExtension:(nullable NSString *)extension
                                   sender:(nullable id)sender
{
    // Play sound in the application's main queue.
    dispatch_async(dispatch_get_main_queue(), ^{
        
        // Assign an audio sound (played when random point sets are generated and saved to file).
        NSError *error = nil;
        
        // No need to check to see if the audioPlayer is nil, since calling 'stop' will do nothing if it's nil.
        if (_audioPlayer.isPlaying)
            [_audioPlayer stop];
        _audioPlayer = nil;
        _audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:
                        [[NSBundle mainBundle] URLForResource:name withExtension:extension]
                                                              error:&error];
        
        // If error, return.
        if (error) {
            
            [self handleError:error];
            return;
        }
        
        // All seems good.
        [_audioPlayer setDelegate:self];
        [_audioPlayer setVolume:1.0f];
        [_audioPlayer prepareToPlay];
        [_audioPlayer play];
    });
}

#pragma mark -
#pragma mark Error Handling

/**
 *  Error handler.
 *
 *  @param error An error.
 */
- (void)handleError:(NSError *)error
{
    // Inform of error in the application's main queue.
    dispatch_async(dispatch_get_main_queue(), ^{
        
        // No need to check to see if the audioPlayer is nil, since calling 'stop' will do nothing if it's nil.
        if (_audioPlayer.isPlaying)
            [_audioPlayer stop];
        _audioPlayer = nil;
        
        // Present the PhotoAlbum info in an AlertController instance.
        UIAlertController *alertController =
        [UIAlertController alertControllerWithTitle:NSLocalizedString(@"App Name", NULL)
                                            message:error.localizedDescription
                                     preferredStyle:UIAlertControllerStyleAlert];
        
        // Establish a "Dismiss" AlertAction object.
        UIAlertAction *dismissAction = [UIAlertAction actionWithTitle:@"Dismiss"
                                                                style:UIAlertActionStyleDefault
                                                              handler:NULL];
        
        // Add the AlertAction object to the AlertController object.
        [alertController addAction:dismissAction];
        
        // Present it.
        [self presentViewController:alertController animated:YES completion:nil];
    });
}

#pragma mark -
#pragma mark GRSceneDelegate
/**
 *  Scene graph did add a new node to its graph.
 *
 *  @param  scene  A Grapher scene associated with this edge.
 *  @param log  A log.
 */
- (void)scene:(GRScene *)scene addedNodeWithLog:(NSMutableString *)log
{
    [self setupAudioPlaybackAndPlayResource:@"Pop" withExtension:@"wav" sender:nil];
}

/**
 *  Scene graph did purge its graph.
 *
 *  @param  scene  A Grapher scene associated with this edge.
 *  @param log  A log.
 */
- (void)scene:(GRScene *)scene purgedGraphWithLog:(NSMutableString *)log
{
    [self setupAudioPlaybackAndPlayResource:@"Kitten" withExtension:@"wav" sender:nil];
}

#pragma mark -
#pragma mark View lifecycle

/**
 *  Called after the view has been loaded,
 */
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // Configure the view.
    SKView * skView = (SKView *)self.view;
    skView.showsFPS = YES;
    skView.showsNodeCount = YES;
    
    /* Sprite Kit applies additional optimizations to improve rendering performance */
    skView.ignoresSiblingOrder = YES;
    
    // Create and configure the scene.
    GRScene *scene = [GRScene nodeWithFileNamed:@"GRScene"];
    scene.sceneDelegate = self;
    scene.scaleMode = SKSceneScaleModeAspectFill;
    scene.backgroundColor = SKColor.darkGrayColor;
    
    // Present the scene.
    [skView presentScene:scene];
    
    // Setup audio playback and play the file.
    [self setupAudioPlaybackAndPlayResource:@"ComputerBeeps2" withExtension:@"wav" sender:nil];
}

/**
 *  Autorotation support.
 *
 *  @return The boolean value.
 */
- (BOOL)shouldAutorotate
{
    return YES;
}

/**
 *  Supported interface orientations.
 *
 *  @return The interface orientation mask value.
 */
- (UIInterfaceOrientationMask)supportedInterfaceOrientations
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        
        return UIInterfaceOrientationMaskAllButUpsideDown;
        
    } else {
        
        return UIInterfaceOrientationMaskAll; // Current device (iPad).
    }
}

/**
 *  Called when the parent application receives a memory warning.
 */
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
    // Dispose of any resources that can be recreated.
    
    // Show the warning.
    [self handleError:[NSError errorWithDomain:NSCocoaErrorDomain
                                          code:kGRErrorCode
                                      userInfo:@{NSLocalizedDescriptionKey:@"Memory Warning!"}]];
}

/**
 *  Controls the attributes of the status bar when this view controller is shown.
 *  They can be overridden in view controller subclasses to return the desired status bar attributes.
 *  Default is NO.
 *
 *  @return The status bar flag.
 */
- (BOOL)prefersStatusBarHidden
{
    return YES;
}

@end
