//
//  GRNode.h
//  Grapher
//
//  Created by Mustafa Youldash on 17/02/2016.
//  Copyright © 2016 Umm Al-Qura University. All rights reserved.
//
//  Except where otherwise noted, this work is vested in Umm Al-Qura University <http://www.uqu.edu.sa/> and is licensed under the
//  Creative Commons Attribution-NonCommercial 4.0 International License <http://creativecommons.org/licenses/by-nc/4.0/>.
//
//  Unless otherwise stated, no part of this work may be reproduced and redistributed by any process,
//  nor used for commercial purposes without the written permission of Umm Al-Qura University and the author.
//
//  If you modify or build upon the work, you may only distribute the resulting work under the same license conditions as this one.
//

@import SpriteKit;

@class GRNode;
@class GRScene;

/**
 *  Protocol implemented by a graph node.
 */
@protocol GRNodeDelegate <NSObject>

#pragma mark -
#pragma mark Accessing

/**
 *  An identifier.
 */
@property (copy, nonatomic) NSString *identifier;

/**
 *  A weight on this graphic.
 */
@property (strong, nonatomic) NSNumber *weight;

/**
 *  The number of this node.
 */
@property (readwrite, nonatomic) NSUInteger number;

/**
 *  Circular reference to a Grapher scene (not retained).
 */
@property (weak, nonatomic) GRScene *scene;

/**
 *  Default node color.
 *
 *  @return The color.
 */
+ (SKColor *)nodeColor;

#pragma mark -
#pragma mark Modifying

/**
 *  Centers this node's position in world space.
 */
- (void)center;

#pragma mark -
#pragma mark Querying

/**
 *  Calculates/recalculates the Euclidean distance.
 *
 *  @return The Euclidean distance from node.
 */
- (double)calculateEuclideanDistanceFromNode:(id<GRNodeDelegate>)node;

@end

#pragma mark -

/**
 *  Represents a node in a scene graph.
 *  According to the definition listed in
 *  <https://developer.apple.com/library/ios/documentation/SpriteKit/Reference/SKNode_Ref/>
 */
@interface GRNode : SKShapeNode <GRNodeDelegate>

#pragma mark -
#pragma mark Initializing

/**
 *  Designated initializer.
 *  Initializes a newly allocated node with an identifier, weight, color, and scene properties.
 *
 *  @param  identifier  An identifier.
 *  @param  weight      A weight.
 *  @param  color       A color.
 *  @param  scene       A Grapher scene associated with this edge.
 *
 *  @return  The new node.
 */
- (instancetype)initWithIdentifier:(id<NSObject>)identifier
                            weight:(NSNumber *)weight
                             color:(SKColor *)color
                             scene:(GRScene *)scene;

/**
 *  Initializes a newly allocated node with an identifier, weight, color, position, and scene properties.
 *
 *  @param  identifier  An identifier.
 *  @param  weight      A weight.
 *  @param  size        A size.
 *  @param  color       A color.
 *  @param  scene       A Grapher scene associated with this edge.
 *
 *  @return  The new node.
 */
- (instancetype)initWithIdentifier:(id<NSObject>)identifier
                            weight:(NSNumber *)weight
                          position:(CGPoint)position
                             color:(SKColor *)color
                             scene:(GRScene *)scene;

@end
