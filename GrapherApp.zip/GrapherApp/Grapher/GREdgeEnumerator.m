//
//  GREdgeEnumerator.m
//  Grapher
//
//  Created by Mustafa Youldash on 20/02/2016.
//  Copyright © 2016 Umm Al-Qura University. All rights reserved.
//
//  Except where otherwise noted, this work is vested in Umm Al-Qura University <http://www.uqu.edu.sa/> and is licensed under the
//  Creative Commons Attribution-NonCommercial 4.0 International License <http://creativecommons.org/licenses/by-nc/4.0/>.
//
//  Unless otherwise stated, no part of this work may be reproduced and redistributed by any process,
//  nor used for commercial purposes without the written permission of Umm Al-Qura University and the author.
//
//  If you modify or build upon the work, you may only distribute the resulting work under the same license conditions as this one.
//

#import "GREdgeEnumerator.h"

@implementation GREdgeEnumerator

#pragma mark -
#pragma mark Initializing

/**
 *  Designed initializer.
 *  Initializes a newly allocated edge enumerator for the given graph.
 *
 *  @param  graph  The graph the edges of which are to be enumerated.
 *
 *  @return  The new edge enumerator.
 */
- (instancetype)initWithGraph:(id<GRGraphDelegate>)graph
{
    // Immutable edge enumerator, just return a new reference to itself (retained automatically by ARC).
    self = [super init];
    
    if (self) {
        
        // Initialize all parameters.
        _graph = graph;
        
        for (_headIdx = 0;
             _headIdx < graph.numberOfNodes;
             ++_headIdx) {
            
            for (_tailIdx = _headIdx + 1;
                 _tailIdx < graph.numberOfNodes;
                 ++_tailIdx) {
                
                if ([graph isEdgeFromIndex:_headIdx
                                   toIndex:_tailIdx])
                    goto found;
            }
        }
        
    found:;
    }
    
    // Return this edge enumerator along with its children.
    return self;
}

#pragma mark -
#pragma mark GREnumeratorDelegate

/**
 *  Returns true if there are more objects to be enumerated.
 *
 *  @return  The boolean result.
 */
- (BOOL)hasMoreObjects
{
    return _headIdx < _graph.numberOfNodes && _tailIdx < _graph.numberOfNodes;
}

/**
 *  Returns the next object to be enumerated.
 *
 *  @return  The next edge.
 */
- (id)nextObject
{
    id result = nil;
    
    if (_headIdx < _graph.numberOfNodes && _tailIdx < _graph.numberOfNodes) {
        
        result = [_graph edgeFromIndex:_headIdx toIndex:_tailIdx];
        
        for (++_tailIdx;
             _tailIdx < _graph.numberOfNodes;
             ++_tailIdx) {
            
            if ([_graph isEdgeFromIndex:_headIdx toIndex:_tailIdx])
                goto found;
        }
        
        for (++_headIdx;
             _headIdx < _graph.numberOfNodes;
             ++_headIdx) {
            
            for (_tailIdx = _headIdx + 1;
                 _tailIdx < _graph.numberOfNodes;
                 ++_tailIdx) {
                
                if ([_graph isEdgeFromIndex:_headIdx toIndex:_tailIdx])
                    goto found;
            }
        }
        
    found:;
    }
    
    return result;
}

@end
