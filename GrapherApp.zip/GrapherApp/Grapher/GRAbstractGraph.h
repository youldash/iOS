//
//  GRAbstractGraph.h
//  Grapher
//
//  Created by Mustafa Youldash on 20/02/2016.
//  Copyright © 2016 Umm Al-Qura University. All rights reserved.
//
//  Except where otherwise noted, this work is vested in Umm Al-Qura University <http://www.uqu.edu.sa/> and is licensed under the
//  Creative Commons Attribution-NonCommercial 4.0 International License <http://creativecommons.org/licenses/by-nc/4.0/>.
//
//  Unless otherwise stated, no part of this work may be reproduced and redistributed by any process,
//  nor used for commercial purposes without the written permission of Umm Al-Qura University and the author.
//
//  If you modify or build upon the work, you may only distribute the resulting work under the same license conditions as this one.
//

#import "GRContainer.h"

@class GRAbstractGraph;
@class GRNode;
@class GREdge;
@class GRScene;
@class GRArray;

@import SpriteKit;

/**
 *  Protocol implemented by all graphs.
 */
@protocol GRGraphDelegate <GRContainerDelegate>

#pragma mark -
#pragma mark Accessing

/**
 *  An identifier.
 */
@property (readonly, nonatomic) NSString *identifier;

/**
 *  The number of nodes.
 */
@property (readonly, nonatomic) NSUInteger numberOfNodes;

/**
 *  The number of edges.
 */
@property (readonly, nonatomic) NSUInteger numberOfEdges;

/**
 *  The nodes in this graph.
 *
 *  An array of pointers to node instances, used to represent the elements of the node set N.
 */
@property (strong, readonly, nonatomic) id<GREnumerableDelegate> nodes;

/**
 *  The edges in this graph.
 *
 *  An array of pointers to edge instances, used to represent the elements of the edge set E.
 */
@property (strong, readonly, nonatomic) id<GREnumerableDelegate> edges;

#pragma mark -
#pragma mark Querying

/**
 *  Returns the node in this graph at the given index.
 *
 *  @param  index  An index.
 *
 *  @return  The node at the given index.
 */
- (GRNode *)nodeAtIndex:(NSUInteger)index;

/**
 *  Returns a boolean value that indicates whether there is an edge in this graph between the nodes with the given indices.
 *
 *  @param  index1  index1 The from index.
 *  @param  index2  index2 The to index.
 *
 *  @return  The boolean result.
 */
- (BOOL)isEdgeFromIndex:(NSUInteger)index1 toIndex:(NSUInteger)index2;

/**
 *  Returns the edge in this graph between the given nodes with the given indices.
 *
 *  @param  index1  The from index.
 *  @param  index2  The to index.
 *
 *  @return  The edge joining the given nodes.
 */
- (GREdge *)edgeFromIndex:(NSUInteger)index1 toIndex:(NSUInteger)index2;

/**
 *  Indicates whether this graph is valid or not.
 *
 *  @return  The boolean result.
 */
- (BOOL)isValid;

#pragma mark -
#pragma mark Mutating

/**
 *  Adds a node to this graph with parameters: identifier, weight, position, color, and scene.
 *  Node's position will be assigned later.
 *  Returns the number of the new node.
 *
 *  This mutator (-addNodeWithIdentifier:weight:size:color:scene:) inserts new node into a graph.
 *  For simplicity, we shall assume that a given node is inserted into exactly one graph.
 *  All the nodes contained in a graph must have a unique node number.
 *  Furthermore, if a graph contains (n) nodes, those nodes shall be numbered 0, 1, 2, ..., n-1.
 *  Therefore, the next node inserted into the graph shall have the number (n).
 *
 *  This accessor (brought forward from -indexOfNode:) takes an integer, say (i) where 0 <= i < n,
 *  and returns reference to the i'th node contained in the graph.
 *
 *  @param  identifier  An identifier.
 *  @param  weight    A weight.
 *  @param  position  A position.
 *  @param  color    A color.
 *  @param  scene    A Grapher scene associated with this edge.
 *
 *  @return  The index of the new node.
 */
- (NSUInteger)addNodeWithIdentifier:(id<NSObject>)identifier
                             weight:(NSNumber *)weight
                           position:(CGPoint)position
                              color:(SKColor *)color
                              scene:(GRScene *)scene;

/**
 *  Adds an edge to this graph between the nodes with the given indices, weight.
 *
 *  @param  index1  The from index.
 *  @param  index2  The to index.
 *  @param  weight  The weight on the edge.
 *  @param  scene  A Grapher scene associated with this edge.
 */
- (void)addEdgeFromIndex:(NSUInteger)index1
                 toIndex:(NSUInteger)index2
                  weight:(NSNumber *)weight
                   scene:(GRScene *)scene;

/**
 *  Removes all the nodes and edges from this graph.
 */
- (void)purge;

#pragma mark -
#pragma mark Enumerating

/**
 *  Returns an enumerator that enumerates the nodes of this graph.
 *
 *  @return  The enumerator.
 */
- (id<GREnumeratorDelegate>)nodeEnumerator;

/**
 *  Returns an enumerator that enumerates the edges of this graph.
 *
 *  @return  The enumerator.
 */
- (id<GREnumeratorDelegate>)edgeEnumerator;

@end

#pragma mark -

/**
 *  Base class from which all graph classes are derived.
 */
@interface GRAbstractGraph : GRContainer <GRGraphDelegate> {
    
    /**
     *  The number of nodes.
     */
    NSUInteger _numberOfNodes;
    
    /**
     *  The number of edges.
     */
    NSUInteger _numberOfEdges;
    
    /**
     *  A "mutable" array of nodes.
     */
    GRArray *_nodeArray;
}

#pragma mark -
#pragma mark Initializing

/**
 *  Designated initializer.
 *  Initializes a newly allocated graph with the given length (maximum number of nodes).
 *
 *  @param  identifier  An identifier.
 *  @param  length    The maximum number of nodes.
 *
 *  @return  The new graph.
 */
- (instancetype)initWithIdentifier:(id<NSObject>)identifier length:(NSUInteger)length;

#pragma mark -
#pragma mark Testing

/**
 *  GRAbstractGraph test program.
 *
 *  @param  graph  The graph to test.
 *
 *  @return  A boolean value that indicates whether all the tests were successful.
 */
+ (BOOL)testGraph:(id<GRGraphDelegate>)graph;

@end
