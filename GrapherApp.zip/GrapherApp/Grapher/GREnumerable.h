//
//  GREnumerable.h
//  Grapher
//
//  Created by Mustafa Youldash on 19/02/2016.
//  Copyright © 2016 Umm Al-Qura University. All rights reserved.
//
//  Except where otherwise noted, this work is vested in Umm Al-Qura University <http://www.uqu.edu.sa/> and is licensed under the
//  Creative Commons Attribution-NonCommercial 4.0 International License <http://creativecommons.org/licenses/by-nc/4.0/>.
//
//  Unless otherwise stated, no part of this work may be reproduced and redistributed by any process,
//  nor used for commercial purposes without the written permission of Umm Al-Qura University and the author.
//
//  If you modify or build upon the work, you may only distribute the resulting work under the same license conditions as this one.
//

#import "GRAbstractEnumerable.h"

/**
 *  An enumerable object facade.
 */
@interface GREnumerable : GRAbstractEnumerable {
    
    /**
     *  An object that provides an enumerator.
     */
    id _target;
    
    /**
     *  Action invoked to get the enumerator from the object.
     */
    SEL _action;
    
    /**
     *  Optional argument for action.
     */
    id _object;
}

#pragma mark -
#pragma mark Initializing

/**
 *  Designed initializer.
 *  Initializes this enumerable object facade for the given target object and action selector.
 *
 *  @param  target  The target object.
 *  @param  action  An action selector.
 *
 *  @return  The new enumerable.
 */
- (instancetype)initWithTarget:(id)target action:(SEL)action;

/**
 *  Initializes this enumerable object facade for the given target object, action selector, and argument object.
 *
 *  @param  target  The target object.
 *  @param  action  An action selector.
 *  @param  object  The argument.
 *
 *  @return  The new enumerable.
 */
- (instancetype)initWithTarget:(id)target action:(SEL)action object:(id)object;

@end
