//
//  GRContainerAsArrayEnumerator.m
//  Grapher
//
//  Created by Mustafa Youldash on 20/02/2016.
//  Copyright © 2016 Umm Al-Qura University. All rights reserved.
//
//  Except where otherwise noted, this work is vested in Umm Al-Qura University <http://www.uqu.edu.sa/> and is licensed under the
//  Creative Commons Attribution-NonCommercial 4.0 International License <http://creativecommons.org/licenses/by-nc/4.0/>.
//
//  Unless otherwise stated, no part of this work may be reproduced and redistributed by any process,
//  nor used for commercial purposes without the written permission of Umm Al-Qura University and the author.
//
//  If you modify or build upon the work, you may only distribute the resulting work under the same license conditions as this one.
//

#import "GRContainerAsArrayEnumerator.h"
#import "GRArray.h"

@implementation GRContainerAsArrayEnumerator

#pragma mark -
#pragma mark Initializing

/**
 *  Designed initializer.
 *  Initializes a newly allocated container as array enumerator for the given container, array, count and start index.
 *
 *  @param  container  The container.
 *  @param  array    The underlying array.
 *  @param  count    The number of objects in the array.
 *  @param  index    The start index.
 *
 *  @return  The new container as array enumerator.
 */
- (instancetype)initWithContainer:(id<GRContainerDelegate>)container
                            array:(GRArray *)array
                            count:(NSUInteger)count
                        fromIndex:(NSUInteger)index
{
    // Immutable container as array enumerator, just return a new reference to itself (retained automatically by ARC).
    self = [super init];
    
    if (self) {
        
        // Initialize all parameters.
        _container = container;
        _array = array;
        _count = count;
        _fromIndex = index;
        _pointer = 0;
    }
    
    // Return this container as array enumerator along with its children.
    return self;
}

#pragma mark -
#pragma mark GREnumeratorDelegate

/**
 *  Returns a boolean that indicates whether there are more objects to be enumerated.
 *
 *  @return  The boolean result.
 */
- (BOOL)hasMoreObjects
{
    return _pointer < _count;
}

/**
 *  Returns the next object to be enumerated.
 *
 *  @return  The next object.
 */
- (id)nextObject
{
    id object = nil;
    
    if (_pointer < _count) {
        
        NSUInteger offset = (_fromIndex + _pointer - _array.baseIndex) % _array.length + _array.baseIndex;
        
        object = [_array objectAtIndex:offset];
        
        _pointer++;
    }
    
    return object;
}

@end
