//
//  GRConnectedNodeEnumerator.m
//  Grapher
//
//  Created by Mustafa Youldash on 18/02/2016.
//  Copyright © 2016 Umm Al-Qura University. All rights reserved.
//
//  Except where otherwise noted, this work is vested in Umm Al-Qura University <http://www.uqu.edu.sa/> and is licensed under the
//  Creative Commons Attribution-NonCommercial 4.0 International License <http://creativecommons.org/licenses/by-nc/4.0/>.
//
//  Unless otherwise stated, no part of this work may be reproduced and redistributed by any process,
//  nor used for commercial purposes without the written permission of Umm Al-Qura University and the author.
//
//  If you modify or build upon the work, you may only distribute the resulting work under the same license conditions as this one.
//

#import "GRConnectedNodeEnumerator.h"
#import "GREdge.h"

@implementation GRConnectedNodeEnumerator

#pragma mark -
#pragma mark Initializing

/**
 *  Designed initializer.
 *  Initializes a newly allocated connected node enumerator with the given node and edge enumerator.
 *
 *  @param  node  A node.
 *  @param  edges  The edges adjacent to the given node.
 *
 *  @return  The new connected node enumerator.
 */
- (instancetype)initWithNode:(GRNode *)node edges:(id<GREnumerableDelegate>)edges
{
    // Immutable connected node enumerator, just return a new reference to itself (retained automatically by ARC).
    self = [super init];
    
    if (self) {
        
        // Initialize all parameters.
        _node = node;
        _enumerator = [edges objectEnumerator];
    }
    
    // Return this connected node enumerator along with its children.
    return self;
}

#pragma mark -
#pragma mark GREnumeratorDelegate

/**
 *  Indicates whether there are more nodes to be enumerated.
 *
 *  @return  The boolean result.
 */
- (BOOL)hasMoreObjects
{
    return [_enumerator hasMoreObjects];
}

/**
 *  The next object to be enumerated.
 *
 *  @return  The next object.
 */
- (id)nextObject
{
    GREdge *edge = [_enumerator nextObject];
    
    return [edge mateOfNode:_node];
}

@end
