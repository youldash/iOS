//
//  GRScene.h
//  Grapher
//
//  Created by Mustafa Youldash on 16/02/2016.
//  Copyright © 2016 Umm Al-Qura University. All rights reserved.
//
//  Except where otherwise noted, this work is vested in Umm Al-Qura University <http://www.uqu.edu.sa/> and is licensed under the
//  Creative Commons Attribution-NonCommercial 4.0 International License <http://creativecommons.org/licenses/by-nc/4.0/>.
//
//  Unless otherwise stated, no part of this work may be reproduced and redistributed by any process,
//  nor used for commercial purposes without the written permission of Umm Al-Qura University and the author.
//
//  If you modify or build upon the work, you may only distribute the resulting work under the same license conditions as this one.
//

@import SpriteKit;

#import "GRAbstractGraph.h"

@class GRScene;

/**
 *  Provides an interface for various scene graph calls.
 */
@protocol GRSceneDelegate <NSObject>

/**
 *  Scene graph did add a new node to its graph.
 *
 *  @param  scene  A Grapher scene associated with this edge.
 *  @param log  A log.
 */
- (void)scene:(GRScene *)scene addedNodeWithLog:(NSMutableString *)log;

/**
 *  Scene graph did purge its graph.
 *
 *  @param  scene  A Grapher scene associated with this edge.
 *  @param log  A log.
 */
- (void)scene:(GRScene *)scene purgedGraphWithLog:(NSMutableString *)log;

@end

#pragma mark -

/**
 *  Provides an interface for playing around with interactive graph data structures.
 */
@interface GRScene : SKScene

#pragma mark -
#pragma mark Accessing

/**
 *  A Grapher scene delegate.
 */
@property (weak, nonatomic) id<GRSceneDelegate> sceneDelegate;

/**
 *  An undirected graph.
 */
@property (strong, nonatomic) id<GRGraphDelegate> graph;

/**
 *  The maximum number of nodes.
 */
@property (readwrite, nonatomic) NSUInteger length;

/**
 *  Logging.
 */
@property (copy, nonatomic) NSMutableString *log;

/**
 *  Indexing.
 */
@property (readwrite, nonatomic) NSUInteger idx;

@end
